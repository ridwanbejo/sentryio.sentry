sentry\_project module
======================

.. automodule:: sentry_project
   :members: DOCUMENTATION, EXAMPLES, RETURN
   :undoc-members:
   :show-inheritance:

   .. autodata:: DOCUMENTATION
      :annotation: =documentation for sentry_project ansible modules

   .. autodata:: EXAMPLES
      :annotation: =examples of sentry_project usage

   .. autodata:: RETURN
      :annotation: =return value of sentry_project ansible modules
