sentry\_organization module
===========================

.. automodule:: sentry_organization
   :members: DOCUMENTATION, EXAMPLES, RETURN
   :undoc-members:
   :show-inheritance:

   .. autodata:: DOCUMENTATION
      :annotation: =documentation for sentry_organization ansible modules

   .. autodata:: EXAMPLES
      :annotation: =examples of sentry_organization usage

   .. autodata:: RETURN
      :annotation: =return value of sentry_organization ansible modules
