sentry\_team module
===================

.. automodule:: sentry_team
   :members: DOCUMENTATION, EXAMPLES, RETURN
   :undoc-members:
   :show-inheritance:

   .. autodata:: DOCUMENTATION
      :annotation: =documentation for sentry_team ansible modules

   .. autodata:: EXAMPLES
      :annotation: =examples of sentry_team usage

   .. autodata:: RETURN
      :annotation: =return value of sentry_team ansible modules
