sentry\_project\_service\_hook module
=====================================

.. automodule:: sentry_project_service_hook
   :members: DOCUMENTATION, EXAMPLES, RETURN
   :undoc-members:
   :show-inheritance:

   .. autodata:: DOCUMENTATION
      :annotation: =documentation for sentry_project_service_hook ansible modules

   .. autodata:: EXAMPLES
      :annotation: =examples of sentry_project_service_hook usage

   .. autodata:: RETURN
      :annotation: =return value of sentry_project_service_hook ansible modules
